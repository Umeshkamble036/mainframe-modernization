      *================================================================*
      * PROGRAM:    CUSTACCT                                           *
      * PURPOSE:    Customer Account Management System                 *
      * AUTHOR:     MAINFRAME-TEAM                                     *
      * DATE:       2024-01-01                                         *
      * VERSION:    1.0                                                *
      *                                                                *
      * AWS M2 NOTES:                                                  *
      *   - Compiled with Enterprise COBOL for z/OS 6.3               *
      *   - Uses VSAM KSDS for CUSTOMER-FILE                          *
      *   - Uses sequential PS file for TRANSACTION-FILE              *
      *   - Calls subprogram VALCUST for validation                   *
      *================================================================*
       IDENTIFICATION DIVISION.
       PROGRAM-ID. CUSTACCT.
       AUTHOR. MAINFRAME-TEAM.
       DATE-WRITTEN. 2024-01-01.
       DATE-COMPILED.

       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. IBM-ZOS.
       OBJECT-COMPUTER. IBM-ZOS.

       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT CUSTOMER-FILE
               ASSIGN TO CUSTFILE
               ORGANIZATION IS INDEXED
               ACCESS MODE IS DYNAMIC
               RECORD KEY IS CUST-ID
               ALTERNATE RECORD KEY IS CUST-EMAIL
                   WITH DUPLICATES
               FILE STATUS IS WS-CUST-STATUS.

           SELECT TRANSACTION-FILE
               ASSIGN TO TRANFILE
               ORGANIZATION IS SEQUENTIAL
               ACCESS MODE IS SEQUENTIAL
               FILE STATUS IS WS-TRAN-STATUS.

           SELECT REPORT-FILE
               ASSIGN TO RPTFILE
               ORGANIZATION IS SEQUENTIAL
               FILE STATUS IS WS-RPT-STATUS.

       DATA DIVISION.
       FILE SECTION.

      *----------------------------------------------------------------*
      * CUSTOMER MASTER FILE - VSAM KSDS                              *
      *----------------------------------------------------------------*
       FD  CUSTOMER-FILE
           LABEL RECORDS ARE STANDARD.
       01  CUSTOMER-RECORD.
           COPY CUSTCOPY.

      *----------------------------------------------------------------*
      * DAILY TRANSACTION INPUT FILE - SEQUENTIAL                     *
      *----------------------------------------------------------------*
       FD  TRANSACTION-FILE
           RECORDING MODE IS F
           BLOCK CONTAINS 0 RECORDS
           LABEL RECORDS ARE STANDARD
           RECORD CONTAINS 96 CHARACTERS.
       01  TRANSACTION-RECORD.
           COPY TRANCOPY.

      *----------------------------------------------------------------*
      * REPORT OUTPUT FILE                                             *
      *----------------------------------------------------------------*
       FD  REPORT-FILE
           RECORDING MODE IS F
           BLOCK CONTAINS 0 RECORDS
           LABEL RECORDS ARE STANDARD
           RECORD CONTAINS 132 CHARACTERS.
       01  REPORT-LINE             PIC X(132).

       WORKING-STORAGE SECTION.
       01  WS-FILE-STATUSES.
           05  WS-CUST-STATUS      PIC XX VALUE SPACES.
               88  CUST-OK         VALUE '00'.
               88  CUST-NOT-FOUND  VALUE '23'.
               88  CUST-DUP-KEY    VALUE '22'.
           05  WS-TRAN-STATUS      PIC XX VALUE SPACES.
               88  TRAN-OK         VALUE '00'.
               88  TRAN-EOF        VALUE '10'.
           05  WS-RPT-STATUS       PIC XX VALUE SPACES.

       01  WS-SWITCHES.
           05  WS-END-OF-FILE      PIC X(1) VALUE 'N'.
               88  END-OF-FILE     VALUE 'Y'.
               88  NOT-END-OF-FILE VALUE 'N'.
           05  WS-RECORD-FOUND     PIC X(1) VALUE 'N'.
               88  RECORD-FOUND    VALUE 'Y'.
               88  RECORD-NOT-FOUND VALUE 'N'.

       01  WS-COUNTERS.
           05  WS-RECORDS-READ     PIC 9(7) VALUE ZEROS.
           05  WS-RECORDS-UPDATED  PIC 9(7) VALUE ZEROS.
           05  WS-RECORDS-SKIPPED  PIC 9(7) VALUE ZEROS.
           05  WS-RECORDS-ERRORS   PIC 9(7) VALUE ZEROS.
           05  WS-TOTAL-DEPOSITS   PIC S9(13)V99 COMP-3 VALUE ZEROS.
           05  WS-TOTAL-WITHDRAWALS PIC S9(13)V99 COMP-3 VALUE ZEROS.
           05  WS-TOTAL-PAYMENTS   PIC S9(13)V99 COMP-3 VALUE ZEROS.

       01  WS-CURRENT-DATE.
           05  WS-CURR-YEAR        PIC 9(4).
           05  WS-CURR-MONTH       PIC 9(2).
           05  WS-CURR-DAY         PIC 9(2).

       01  WS-WORK-AREAS.
           05  WS-RETURN-CODE      PIC 9(4) VALUE ZEROS.
           05  WS-ERROR-MSG        PIC X(80) VALUE SPACES.
           05  WS-FORMATTED-BAL    PIC ZZZ,ZZZ,ZZ9.99-.
           05  WS-FORMATTED-AMT    PIC ZZZ,ZZZ,ZZ9.99-.

       01  WS-REPORT-HEADER-1.
           05  FILLER              PIC X(45)
               VALUE '         CUSTOMER ACCOUNT MANAGEMENT REPORT'.
           05  FILLER              PIC X(40) VALUE SPACES.
           05  WS-RPT-DATE         PIC X(10) VALUE SPACES.
           05  FILLER              PIC X(37) VALUE SPACES.

       01  WS-REPORT-HEADER-2.
           05  FILLER PIC X(10) VALUE 'CUST-ID'.
           05  FILLER PIC X(2)  VALUE SPACES.
           05  FILLER PIC X(35) VALUE 'CUSTOMER NAME'.
           05  FILLER PIC X(10) VALUE 'TXN-TYPE'.
           05  FILLER PIC X(2)  VALUE SPACES.
           05  FILLER PIC X(15) VALUE 'AMOUNT'.
           05  FILLER PIC X(2)  VALUE SPACES.
           05  FILLER PIC X(15) VALUE 'NEW BALANCE'.
           05  FILLER PIC X(33) VALUE SPACES.

       01  WS-DETAIL-LINE.
           05  WS-DL-CUST-ID       PIC Z(9)9.
           05  FILLER              PIC X(2) VALUE SPACES.
           05  WS-DL-NAME          PIC X(35).
           05  FILLER              PIC X(2) VALUE SPACES.
           05  WS-DL-TXN-TYPE      PIC X(10).
           05  FILLER              PIC X(2) VALUE SPACES.
           05  WS-DL-AMOUNT        PIC ZZZ,ZZZ,ZZ9.99-.
           05  FILLER              PIC X(2) VALUE SPACES.
           05  WS-DL-BALANCE       PIC ZZZ,ZZZ,ZZ9.99-.
           05  FILLER              PIC X(20) VALUE SPACES.

       01  WS-ERROR-LINE.
           05  FILLER              PIC X(8)  VALUE '** ERR: '.
           05  WS-ERR-CUST-ID      PIC 9(10).
           05  FILLER              PIC X(3)  VALUE ' - '.
           05  WS-ERR-MESSAGE      PIC X(60).
           05  FILLER              PIC X(51) VALUE SPACES.

       01  WS-SUMMARY-LINE-1.
           05  FILLER              PIC X(30)
               VALUE 'RECORDS READ:              '.
           05  WS-SUM-READ         PIC ZZZ,ZZ9.
           05  FILLER              PIC X(95) VALUE SPACES.

       01  WS-SUMMARY-LINE-2.
           05  FILLER              PIC X(30)
               VALUE 'RECORDS UPDATED:           '.
           05  WS-SUM-UPDATED      PIC ZZZ,ZZ9.
           05  FILLER              PIC X(95) VALUE SPACES.

       01  WS-SUMMARY-LINE-3.
           05  FILLER              PIC X(30)
               VALUE 'RECORDS IN ERROR:          '.
           05  WS-SUM-ERRORS       PIC ZZZ,ZZ9.
           05  FILLER              PIC X(95) VALUE SPACES.

       01  WS-SUMMARY-LINE-4.
           05  FILLER              PIC X(30)
               VALUE 'TOTAL DEPOSITS:            '.
           05  WS-SUM-DEPOSITS     PIC ZZ,ZZZ,ZZZ,ZZ9.99-.
           05  FILLER              PIC X(82) VALUE SPACES.

       01  WS-SUMMARY-LINE-5.
           05  FILLER              PIC X(30)
               VALUE 'TOTAL WITHDRAWALS:         '.
           05  WS-SUM-WITHDRAWALS  PIC ZZ,ZZZ,ZZZ,ZZ9.99-.
           05  FILLER              PIC X(82) VALUE SPACES.

       PROCEDURE DIVISION.

      *================================================================*
       0000-MAIN.
           PERFORM 1000-INITIALIZE
           PERFORM 2000-PROCESS-TRANSACTIONS
               UNTIL END-OF-FILE
           PERFORM 3000-FINALIZE
           MOVE WS-RECORDS-ERRORS TO RETURN-CODE
           STOP RUN.

      *================================================================*
       1000-INITIALIZE.
           MOVE FUNCTION CURRENT-DATE(1:8) TO WS-CURRENT-DATE
           OPEN INPUT  TRANSACTION-FILE
           IF NOT TRAN-OK
               DISPLAY 'ERROR OPENING TRANSACTION FILE: ' WS-TRAN-STATUS
               MOVE 12 TO RETURN-CODE
               STOP RUN
           END-IF
           OPEN I-O    CUSTOMER-FILE
           IF NOT CUST-OK
               DISPLAY 'ERROR OPENING CUSTOMER FILE: ' WS-CUST-STATUS
               MOVE 12 TO RETURN-CODE
               STOP RUN
           END-IF
           OPEN OUTPUT REPORT-FILE
           PERFORM 1100-WRITE-REPORT-HEADERS
           PERFORM 1200-READ-NEXT-TRANSACTION.

       1100-WRITE-REPORT-HEADERS.
           STRING WS-CURR-MONTH '/' WS-CURR-DAY '/' WS-CURR-YEAR
               DELIMITED SIZE INTO WS-RPT-DATE
           WRITE REPORT-LINE FROM WS-REPORT-HEADER-1
           WRITE REPORT-LINE FROM WS-REPORT-HEADER-2
           MOVE ALL '-' TO REPORT-LINE
           WRITE REPORT-LINE.

       1200-READ-NEXT-TRANSACTION.
           READ TRANSACTION-FILE INTO TRANSACTION-RECORD
               AT END
                   MOVE 'Y' TO WS-END-OF-FILE
               NOT AT END
                   ADD 1 TO WS-RECORDS-READ
           END-READ.

      *================================================================*
       2000-PROCESS-TRANSACTIONS.
           PERFORM 2100-LOOKUP-CUSTOMER
           EVALUATE TRUE
               WHEN RECORD-FOUND
                   PERFORM 2200-VALIDATE-TRANSACTION
                   IF WS-RETURN-CODE = ZEROS
                       PERFORM 2300-APPLY-TRANSACTION
                       PERFORM 2400-UPDATE-CUSTOMER-RECORD
                       PERFORM 2500-WRITE-DETAIL-LINE
                   ELSE
                       PERFORM 2600-WRITE-ERROR-LINE
                       ADD 1 TO WS-RECORDS-ERRORS
                   END-IF
               WHEN RECORD-NOT-FOUND
                   MOVE 'CUSTOMER NOT FOUND IN MASTER FILE'
                       TO WS-ERROR-MSG
                   PERFORM 2600-WRITE-ERROR-LINE
                   ADD 1 TO WS-RECORDS-ERRORS
           END-EVALUATE
           PERFORM 1200-READ-NEXT-TRANSACTION.

       2100-LOOKUP-CUSTOMER.
           MOVE TXN-CUST-ID TO CUST-ID
           MOVE 'N'         TO WS-RECORD-FOUND
           READ CUSTOMER-FILE
               INVALID KEY
                   CONTINUE
               NOT INVALID KEY
                   MOVE 'Y' TO WS-RECORD-FOUND
           END-READ.

       2200-VALIDATE-TRANSACTION.
           MOVE ZEROS TO WS-RETURN-CODE
           EVALUATE TRUE
               WHEN TXN-AMOUNT <= ZEROS
                   MOVE 8 TO WS-RETURN-CODE
                   MOVE 'TRANSACTION AMOUNT MUST BE POSITIVE'
                       TO WS-ERROR-MSG
               WHEN NOT CUST-ACTIVE
                   MOVE 4 TO WS-RETURN-CODE
                   MOVE 'ACCOUNT IS NOT IN ACTIVE STATUS'
                       TO WS-ERROR-MSG
               WHEN TXN-WITHDRAWAL AND
                    TXN-AMOUNT > CUST-ACCOUNT-BAL
                   MOVE 8 TO WS-RETURN-CODE
                   MOVE 'INSUFFICIENT FUNDS FOR WITHDRAWAL'
                       TO WS-ERROR-MSG
               WHEN TXN-WITHDRAWAL AND
                    CUST-ACCOUNT-BAL - TXN-AMOUNT < CUST-MIN-BALANCE
                   MOVE 8 TO WS-RETURN-CODE
                   MOVE 'WITHDRAWAL WOULD BREACH MINIMUM BALANCE'
                       TO WS-ERROR-MSG
           END-EVALUATE.

       2300-APPLY-TRANSACTION.
           EVALUATE TRUE
               WHEN TXN-DEPOSIT
                   ADD TXN-AMOUNT TO CUST-ACCOUNT-BAL
                   ADD TXN-AMOUNT TO WS-TOTAL-DEPOSITS
               WHEN TXN-WITHDRAWAL
                   SUBTRACT TXN-AMOUNT FROM CUST-ACCOUNT-BAL
                   ADD TXN-AMOUNT TO WS-TOTAL-WITHDRAWALS
               WHEN TXN-PAYMENT
                   SUBTRACT TXN-AMOUNT FROM CUST-ACCOUNT-BAL
                   IF CUST-ACCOUNT-BAL < ZEROS
                       MOVE ZEROS TO CUST-ACCOUNT-BAL
                   END-IF
                   ADD TXN-AMOUNT TO WS-TOTAL-PAYMENTS
               WHEN TXN-TRANSFER
                   SUBTRACT TXN-AMOUNT FROM CUST-ACCOUNT-BAL
                   ADD TXN-AMOUNT TO WS-TOTAL-WITHDRAWALS
               WHEN OTHER
                   MOVE 8 TO WS-RETURN-CODE
                   MOVE 'UNKNOWN TRANSACTION TYPE CODE'
                       TO WS-ERROR-MSG
           END-EVALUATE.

       2400-UPDATE-CUSTOMER-RECORD.
           MOVE TXN-DATE        TO CUST-LAST-TXN-DATE
           ADD  1               TO CUST-TXN-COUNT
           REWRITE CUSTOMER-RECORD
               INVALID KEY
                   MOVE 'FAILED TO REWRITE CUSTOMER RECORD'
                       TO WS-ERROR-MSG
                   ADD 1 TO WS-RECORDS-ERRORS
               NOT INVALID KEY
                   ADD 1 TO WS-RECORDS-UPDATED
           END-REWRITE.

       2500-WRITE-DETAIL-LINE.
           MOVE CUST-ID            TO WS-DL-CUST-ID
           STRING CUST-FIRST-NAME SPACE CUST-LAST-NAME
               DELIMITED SIZE INTO WS-DL-NAME
           EVALUATE TRUE
               WHEN TXN-DEPOSIT    MOVE 'DEPOSIT   ' TO WS-DL-TXN-TYPE
               WHEN TXN-WITHDRAWAL MOVE 'WITHDRAWAL' TO WS-DL-TXN-TYPE
               WHEN TXN-PAYMENT    MOVE 'PAYMENT   ' TO WS-DL-TXN-TYPE
               WHEN TXN-TRANSFER   MOVE 'TRANSFER  ' TO WS-DL-TXN-TYPE
           END-EVALUATE
           MOVE TXN-AMOUNT         TO WS-DL-AMOUNT
           MOVE CUST-ACCOUNT-BAL   TO WS-DL-BALANCE
           WRITE REPORT-LINE FROM WS-DETAIL-LINE.

       2600-WRITE-ERROR-LINE.
           MOVE TXN-CUST-ID        TO WS-ERR-CUST-ID
           MOVE WS-ERROR-MSG       TO WS-ERR-MESSAGE
           WRITE REPORT-LINE FROM WS-ERROR-LINE.

      *================================================================*
       3000-FINALIZE.
           PERFORM 3100-WRITE-SUMMARY
           CLOSE TRANSACTION-FILE
           CLOSE CUSTOMER-FILE
           CLOSE REPORT-FILE.

       3100-WRITE-SUMMARY.
           MOVE ALL '-' TO REPORT-LINE
           WRITE REPORT-LINE
           MOVE WS-RECORDS-READ     TO WS-SUM-READ
           WRITE REPORT-LINE FROM WS-SUMMARY-LINE-1
           MOVE WS-RECORDS-UPDATED  TO WS-SUM-UPDATED
           WRITE REPORT-LINE FROM WS-SUMMARY-LINE-2
           MOVE WS-RECORDS-ERRORS   TO WS-SUM-ERRORS
           WRITE REPORT-LINE FROM WS-SUMMARY-LINE-3
           MOVE WS-TOTAL-DEPOSITS   TO WS-SUM-DEPOSITS
           WRITE REPORT-LINE FROM WS-SUMMARY-LINE-4
           MOVE WS-TOTAL-WITHDRAWALS TO WS-SUM-WITHDRAWALS
           WRITE REPORT-LINE FROM WS-SUMMARY-LINE-5.
