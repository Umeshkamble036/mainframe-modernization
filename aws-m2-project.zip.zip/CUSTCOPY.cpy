      *================================================================*
      * COPYBOOK: CUSTCOPY                                             *
      * PURPOSE:  Customer Master Record Layout                        *
      * USED BY:  CUSTACCT, CUSTRPT, CUSTVAL, CUSTMNT                 *
      *================================================================*
       01  CUSTOMER-RECORD.
           05  CUST-ID             PIC 9(10).
           05  CUST-NAME.
               10  CUST-LAST-NAME  PIC X(20).
               10  CUST-FIRST-NAME PIC X(15).
           05  CUST-ADDRESS.
               10  CUST-STREET     PIC X(30).
               10  CUST-CITY       PIC X(20).
               10  CUST-STATE      PIC X(2).
               10  CUST-ZIP        PIC 9(5).
           05  CUST-PHONE          PIC 9(10).
           05  CUST-EMAIL          PIC X(40).
           05  CUST-ACCOUNT-BAL    PIC S9(11)V99 COMP-3.
           05  CUST-CREDIT-LIMIT   PIC S9(9)V99  COMP-3.
           05  CUST-MIN-BALANCE    PIC S9(7)V99  COMP-3.
           05  CUST-STATUS         PIC X(1).
               88  CUST-ACTIVE     VALUE 'A'.
               88  CUST-INACTIVE   VALUE 'I'.
               88  CUST-SUSPENDED  VALUE 'S'.
               88  CUST-CLOSED     VALUE 'C'.
           05  CUST-OPEN-DATE      PIC 9(8).
           05  CUST-LAST-TXN-DATE  PIC 9(8).
           05  CUST-TXN-COUNT      PIC 9(7) COMP-3.
           05  CUST-BRANCH-CODE    PIC 9(4).
           05  CUST-FILLER         PIC X(10).
