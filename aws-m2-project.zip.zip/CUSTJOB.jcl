//CUSTJOB  JOB (ACCT001,DEPT02),'CUST ACCT BATCH',
//         CLASS=A,MSGCLASS=X,MSGLEVEL=(1,1),
//         NOTIFY=&SYSUID,REGION=0M,
//         TIME=(0,30)
//*
//* ================================================================ *
//* JOB:     CUSTJOB                                                  *
//* PURPOSE: Daily Customer Account Transaction Processing            *
//* SCHEDULE: Daily at 02:00 via CA7 (job CUSTDLY)                   *
//* ================================================================ *
//*
//JOBLIB   DD  DSN=PROD.CUSTAPP.LOADLIB,DISP=SHR
//*
//* --------------------------------------------------------------- *
//* STEP 1: SORT TRANSACTIONS BY CUSTOMER ID                         *
//* --------------------------------------------------------------- *
//STEP010  EXEC PGM=SORT
//SYSOUT   DD  SYSOUT=*
//SORTIN   DD  DSN=PROD.DAILY.TRANSACTIONS.RAW,
//             DISP=SHR
//SORTOUT  DD  DSN=PROD.DAILY.TRANSACTIONS.SORTED,
//             DISP=(NEW,CATLG,DELETE),
//             SPACE=(CYL,(10,5)),
//             DCB=(RECFM=FB,LRECL=96,BLKSIZE=9600)
//SYSIN    DD  *
  SORT FIELDS=(1,10,CH,A)
  SUM FIELDS=NONE
/*
//*
//* --------------------------------------------------------------- *
//* STEP 2: RUN ACCOUNT PROCESSING PROGRAM                           *
//* --------------------------------------------------------------- *
//STEP020  EXEC PGM=CUSTACCT,COND=(0,NE,STEP010)
//STEPLIB  DD  DSN=PROD.CUSTAPP.LOADLIB,DISP=SHR
//*
//CUSTFILE DD  DSN=PROD.CUSTOMER.MASTER,
//             DISP=SHR
//*
//TRANFILE DD  DSN=PROD.DAILY.TRANSACTIONS.SORTED,
//             DISP=SHR
//*
//RPTFILE  DD  DSN=PROD.ACCOUNT.REPORT.&DATE.,
//             DISP=(NEW,CATLG,DELETE),
//             SPACE=(CYL,(5,2)),
//             DCB=(RECFM=FB,LRECL=132,BLKSIZE=13200)
//*
//SYSOUT   DD  SYSOUT=*
//SYSPRINT DD  SYSOUT=*
//CEEDUMP  DD  SYSOUT=*
//SYSUDUMP DD  SYSOUT=*
//*
//* --------------------------------------------------------------- *
//* STEP 3: ARCHIVE PROCESSED TRANSACTIONS                           *
//* --------------------------------------------------------------- *
//STEP030  EXEC PGM=IEBGENER,COND=(0,NE,STEP020)
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  DSN=PROD.DAILY.TRANSACTIONS.SORTED,
//             DISP=SHR
//SYSUT2   DD  DSN=PROD.TRANSACTIONS.ARCHIVE.&DATE.,
//             DISP=(NEW,CATLG,DELETE),
//             SPACE=(CYL,(10,5)),
//             DCB=(RECFM=FB,LRECL=96,BLKSIZE=9600)
//SYSIN    DD  DUMMY
//
