# AWS Mainframe Modernization (M2) - Customer Account Project
## Complete Setup & Deployment Guide

---

## What is AWS M2?

AWS Mainframe Modernization (M2) lets you run your existing COBOL/PL/I programs
in AWS **without rewriting them**. You lift the programs to the cloud and run them
on either:
- **Micro Focus runtime** — for IBM Enterprise COBOL compatibility (used here)
- **Blu Age runtime** — for automated refactoring to Java/Spring

---

## Project File Structure

```
aws-m2-project/
│
├── source/
│   ├── cobol/
│   │   └── CUSTACCT.cbl          ← Main COBOL program
│   ├── copybooks/
│   │   ├── CUSTCOPY.cpy          ← Customer record layout
│   │   └── TRANCOPY.cpy          ← Transaction record layout
│   └── jcl/
│       └── CUSTJOB.jcl           ← Batch job definition
│
├── config/
│   ├── m2-application-definition.yaml   ← M2 app config (MAIN FILE)
│   ├── cloudformation-m2-environment.yaml  ← AWS infrastructure
│   ├── batch-scheduler.yaml     ← Daily job scheduler
│   └── dataset-import.yaml      ← VSAM migration config
│
├── data/
│   ├── vsam/
│   │   └── CUSTOMER.MASTER.dat  ← Sample customer master (VSAM dump)
│   └── flat-files/
│       └── DAILY.TRANSACTIONS.RAW.dat  ← Sample daily transactions
│
├── scripts/
│   └── deploy-to-m2.sh          ← Automated deployment script
│
└── README.md                    ← This file
```

---

## Step-by-Step Deployment

### Prerequisites
- AWS account with M2 service enabled
- AWS CLI v2 installed: `aws --version`
- IAM permissions: `AmazonM2FullAccess`, `AmazonS3FullAccess`, `CloudFormationFullAccess`

---

### Step 1: Compile Your COBOL

On a machine with Micro Focus COBOL installed:

```bash
# Install Micro Focus COBOL (if not installed)
# Download from: https://www.microfocus.com/en-us/products/visual-cobol/

# Compile the program
cobc -x -o CUSTACCT \
  -I source/copybooks/ \
  source/cobol/CUSTACCT.cbl

# Verify it compiled
ls -la CUSTACCT
```

> **Skip this step** if you have existing `.gnt` or `.so` load modules from
> your mainframe COBOL migration tool. Upload those directly to S3.

---

### Step 2: Run the Deployment Script

```bash
# Make executable
chmod +x scripts/deploy-to-m2.sh

# Deploy (replace with your bucket name)
./scripts/deploy-to-m2.sh \
  --env custacct-prod \
  --bucket my-m2-artifacts-bucket \
  --region us-east-1
```

This script will:
1. Create all S3 buckets
2. Upload COBOL source, copybooks, JCL, and data files
3. Deploy the CloudFormation stack (EFS, security groups, IAM roles)
4. Register the M2 application

---

### Step 3: Import VSAM Data

If you have existing mainframe customer data, import it:

**On mainframe** - export your VSAM to flat file:
```jcl
//EXPORT   EXEC PGM=IDCAMS
//SYSPRINT DD  SYSOUT=*
//INFILE   DD  DSN=PROD.CUSTOMER.MASTER,DISP=SHR
//OUTFILE  DD  DSN=PROD.CUSTOMER.DUMP,DISP=(NEW,CATLG),
//             DCB=(RECFM=FB,LRECL=200)
//SYSIN    DD  *
  REPRO INFILE(INFILE) OUTFILE(OUTFILE)
/*
```

**Then upload to S3 and import:**
```bash
# Upload the dump
aws s3 cp PROD.CUSTOMER.DUMP \
  s3://my-m2-artifacts-bucket/datasets/vsam/CUSTOMER.MASTER.dat

# Or use sample data already provided:
aws s3 cp data/vsam/CUSTOMER.MASTER.dat \
  s3://my-m2-artifacts-bucket/datasets/vsam/

# Submit the import task
aws m2 create-data-set-import-task \
  --application-id <your-app-id> \
  --import-config file://config/dataset-import.yaml \
  --region us-east-1
```

---

### Step 4: Deploy Application to M2 Environment

In the **AWS Console**:
1. Go to **AWS Mainframe Modernization**
2. Click your application: `customer-account-app`
3. Click **Deploy** → select environment: `custacct-prod`
4. Wait for status: **Deployed**

Or via CLI:
```bash
aws m2 create-deployment \
  --application-id <app-id> \
  --application-version 1 \
  --environment-id <env-id> \
  --region us-east-1
```

---

### Step 5: Upload Daily Transaction File

Each day, upload the transaction file to S3 before the job runs:
```bash
# Replace with actual date
DATE=$(date +%Y%m%d)

aws s3 cp data/flat-files/DAILY.TRANSACTIONS.RAW.dat \
  s3://my-m2-input-bucket/daily-transactions/raw/TRANSACTIONS_${DATE}.dat
```

---

### Step 6: Run the Batch Job

**Manual run from AWS Console:**
1. Go to M2 → Applications → customer-account-app
2. Click **Batch jobs** → **CUSTJOB**
3. Click **Submit job**

**Manual run via CLI:**
```bash
aws m2 start-batch-job \
  --application-id <app-id> \
  --batch-job-identifier "jobName=CUSTJOB" \
  --job-params "DATE=$(date +%Y%m%d)" \
  --region us-east-1
```

**Check job status:**
```bash
aws m2 list-batch-job-executions \
  --application-id <app-id> \
  --region us-east-1
```

**Set up automatic daily scheduling:**
```bash
aws cloudformation deploy \
  --template-file config/batch-scheduler.yaml \
  --stack-name custjob-scheduler \
  --parameter-overrides \
    M2ApplicationId=<app-id> \
    M2EnvironmentId=<env-id> \
  --capabilities CAPABILITY_IAM \
  --region us-east-1
```

---

### Step 7: Monitor & View Output

**View batch job logs:**
```bash
aws logs get-log-events \
  --log-group-name "/aws/m2/custacct-prod/batch" \
  --log-stream-name "CUSTJOB/latest" \
  --region us-east-1
```

**Retrieve the output report:**
```bash
aws s3 ls s3://my-m2-output-bucket/reports/account-report/
aws s3 cp s3://my-m2-output-bucket/reports/account-report/ACCOUNT.REPORT.dat .
cat ACCOUNT.REPORT.dat
```

---

## Data Flow on AWS M2

```
S3 (Input)                  M2 Runtime (Micro Focus)         S3 / EFS (Output)
─────────────────           ─────────────────────────        ──────────────────
DAILY.TRANSACTIONS.RAW  ──► CUSTJOB (JCL)                   ACCOUNT.REPORT
                              │                          ──► (S3 output bucket)
                              ├─ SORT step                   
                              │   sorts by CUST-ID           CUSTOMER.MASTER
                              │                          ──► (EFS - updated)
                              └─ CUSTACCT (COBOL)
                                  reads CUSTOMER.MASTER       TRANSACTIONS.ARCHIVE
                                  applies transactions    ──► (S3 archive bucket)
                                  writes report
```

---

## Cost Estimate (us-east-1)

| Resource | Config | Est. Monthly Cost |
|---|---|---|
| M2 Environment | M2.m5.xlarge | ~$800/mo |
| Amazon EFS | 1 GB VSAM data | ~$1/mo |
| S3 Storage | 10 GB across buckets | ~$0.25/mo |
| EventBridge Scheduler | 30 daily runs | ~$0.01/mo |
| CloudWatch Logs | Batch logs | ~$5/mo |

> Stop the M2 environment when not in use to reduce costs.
> `aws m2 stop-environment --environment-id <env-id>`

---

## Troubleshooting

| Problem | Solution |
|---|---|
| Job fails with `FILE STATUS 35` | CUSTFILE dataset not found - run dataset import first |
| Job fails with `FILE STATUS 23` | Customer ID not in master - verify VSAM data loaded |
| Compilation errors | Check copybook path: `-I source/copybooks/` |
| EFS mount fails | Check security group allows port 2049 from M2 |
| S3 access denied | Verify M2 service role has s3:GetObject permission |

---

## Next Steps: Full Java Transformation

After validating your COBOL runs on M2, you can optionally use
**AWS Blu Age** to auto-refactor the COBOL to Java/Spring Boot:

1. Change `engineType: bluage` in `m2-application-definition.yaml`
2. Blu Age generates Java source code from COBOL
3. Review and customize the generated Java code
4. Deploy as a standard Java Spring Boot application

See the `../java/` folder in this project for the manually-transformed
Java version with full annotations.
