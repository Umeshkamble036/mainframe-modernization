      *================================================================*
      * COPYBOOK: TRANCOPY                                             *
      * PURPOSE:  Daily Transaction Record Layout (96 bytes)           *
      * USED BY:  CUSTACCT, TRANRPT, TRANVAL                          *
      *================================================================*
       01  TRANSACTION-RECORD.
           05  TXN-CUST-ID         PIC 9(10).
           05  TXN-TYPE            PIC X(2).
               88  TXN-DEPOSIT     VALUE 'DP'.
               88  TXN-WITHDRAWAL  VALUE 'WD'.
               88  TXN-TRANSFER    VALUE 'TR'.
               88  TXN-PAYMENT     VALUE 'PM'.
           05  TXN-AMOUNT          PIC S9(9)V99  COMP-3.
           05  TXN-DATE            PIC 9(8).
           05  TXN-TIME            PIC 9(6).
           05  TXN-REFERENCE       PIC X(16).
           05  TXN-DESCRIPTION     PIC X(40).
           05  TXN-CHANNEL         PIC X(3).
               88  TXN-BRANCH      VALUE 'BRN'.
               88  TXN-ATM         VALUE 'ATM'.
               88  TXN-ONLINE      VALUE 'WEB'.
               88  TXN-MOBILE      VALUE 'MOB'.
           05  TXN-FILLER          PIC X(3).
