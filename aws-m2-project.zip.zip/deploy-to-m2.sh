#!/bin/bash
# =============================================================================
# AWS M2 Deployment Script
# Uploads all artifacts to S3 and deploys the M2 application
#
# Prerequisites:
#   - AWS CLI installed and configured (aws configure)
#   - jq installed (for JSON parsing)
#   - Micro Focus COBOL compiler installed (for local compile step)
#
# Usage:
#   chmod +x deploy-to-m2.sh
#   ./deploy-to-m2.sh --env prod --bucket my-m2-artifacts-bucket
# =============================================================================

set -euo pipefail

# --- Default Config -----------------------------------------------------------
ARTIFACTS_BUCKET="my-m2-artifacts-bucket"
INPUT_BUCKET="my-m2-input-bucket"
OUTPUT_BUCKET="my-m2-output-bucket"
ARCHIVE_BUCKET="my-m2-archive-bucket"
APP_NAME="customer-account-app"
APP_VERSION="v1.0"
ENV_NAME="custacct-prod"
AWS_REGION="us-east-1"

# --- Parse Arguments ----------------------------------------------------------
while [[ $# -gt 0 ]]; do
  case $1 in
    --env)        ENV_NAME="$2"; shift 2 ;;
    --bucket)     ARTIFACTS_BUCKET="$2"; shift 2 ;;
    --version)    APP_VERSION="$2"; shift 2 ;;
    --region)     AWS_REGION="$2"; shift 2 ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

S3_BASE="s3://${ARTIFACTS_BUCKET}/${APP_NAME}/${APP_VERSION}"

echo "============================================================"
echo "  AWS M2 Deployment - ${APP_NAME} ${APP_VERSION}"
echo "  Environment : ${ENV_NAME}"
echo "  Region      : ${AWS_REGION}"
echo "  S3 Base     : ${S3_BASE}"
echo "============================================================"

# --- Step 1: Create S3 Buckets (if not exist) ---------------------------------
echo ""
echo "[1/6] Creating S3 buckets..."
for BUCKET in $ARTIFACTS_BUCKET $INPUT_BUCKET $OUTPUT_BUCKET $ARCHIVE_BUCKET; do
  if aws s3api head-bucket --bucket "$BUCKET" 2>/dev/null; then
    echo "  ✓ Bucket exists: $BUCKET"
  else
    aws s3api create-bucket \
      --bucket "$BUCKET" \
      --region "$AWS_REGION" \
      --create-bucket-configuration LocationConstraint="$AWS_REGION" \
      2>/dev/null || true
    aws s3api put-bucket-encryption \
      --bucket "$BUCKET" \
      --server-side-encryption-configuration \
        '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'
    echo "  ✓ Created bucket: $BUCKET"
  fi
done

# --- Step 2: Upload COBOL Source Files ----------------------------------------
echo ""
echo "[2/6] Uploading COBOL source files..."
aws s3 cp source/cobol/       "${S3_BASE}/source/cobol/"     --recursive --region "$AWS_REGION"
aws s3 cp source/copybooks/   "${S3_BASE}/copybooks/"        --recursive --region "$AWS_REGION"
aws s3 cp source/jcl/         "${S3_BASE}/jcl/"              --recursive --region "$AWS_REGION"
echo "  ✓ Source files uploaded"

# --- Step 3: Compile COBOL (Micro Focus) --------------------------------------
echo ""
echo "[3/6] Compiling COBOL programs..."
mkdir -p build/loadlib

# Compile main program
if command -v cobc &> /dev/null; then
  cobc -x -o build/loadlib/CUSTACCT \
    -I source/copybooks/ \
    source/cobol/CUSTACCT.cbl
  echo "  ✓ CUSTACCT compiled successfully"
else
  echo "  ⚠ COBOL compiler not found locally - assuming pre-compiled load modules exist"
  echo "    Upload your .gnt files manually to: ${S3_BASE}/loadlib/"
fi

# Upload load modules
if [ -d "build/loadlib" ] && [ "$(ls -A build/loadlib)" ]; then
  aws s3 cp build/loadlib/ "${S3_BASE}/loadlib/" --recursive --region "$AWS_REGION"
  echo "  ✓ Load modules uploaded"
fi

# --- Step 4: Upload Sample Data Files -----------------------------------------
echo ""
echo "[4/6] Uploading data files..."
aws s3 cp data/vsam/          "s3://${ARTIFACTS_BUCKET}/datasets/vsam/"   --recursive --region "$AWS_REGION"
aws s3 cp data/flat-files/    "s3://${INPUT_BUCKET}/daily-transactions/raw/" --recursive --region "$AWS_REGION"
echo "  ✓ Data files uploaded"

# --- Step 5: Deploy CloudFormation Stack --------------------------------------
echo ""
echo "[5/6] Deploying CloudFormation stack..."
STACK_NAME="${ENV_NAME}-m2-stack"

if aws cloudformation describe-stacks --stack-name "$STACK_NAME" --region "$AWS_REGION" &>/dev/null; then
  echo "  Updating existing stack: $STACK_NAME"
  aws cloudformation update-stack \
    --stack-name "$STACK_NAME" \
    --template-body file://config/cloudformation-m2-environment.yaml \
    --parameters \
      ParameterKey=EnvironmentName,ParameterValue="$ENV_NAME" \
      ParameterKey=ArtifactsBucketName,ParameterValue="$ARTIFACTS_BUCKET" \
      ParameterKey=InputBucketName,ParameterValue="$INPUT_BUCKET" \
      ParameterKey=OutputBucketName,ParameterValue="$OUTPUT_BUCKET" \
      ParameterKey=ArchiveBucketName,ParameterValue="$ARCHIVE_BUCKET" \
    --capabilities CAPABILITY_IAM CAPABILITY_NAMED_IAM \
    --region "$AWS_REGION" || echo "  No changes needed."
else
  echo "  Creating new stack: $STACK_NAME"
  aws cloudformation create-stack \
    --stack-name "$STACK_NAME" \
    --template-body file://config/cloudformation-m2-environment.yaml \
    --parameters \
      ParameterKey=EnvironmentName,ParameterValue="$ENV_NAME" \
      ParameterKey=ArtifactsBucketName,ParameterValue="$ARTIFACTS_BUCKET" \
      ParameterKey=InputBucketName,ParameterValue="$INPUT_BUCKET" \
      ParameterKey=OutputBucketName,ParameterValue="$OUTPUT_BUCKET" \
      ParameterKey=ArchiveBucketName,ParameterValue="$ARCHIVE_BUCKET" \
    --capabilities CAPABILITY_IAM CAPABILITY_NAMED_IAM \
    --region "$AWS_REGION"

  echo "  Waiting for stack to complete..."
  aws cloudformation wait stack-create-complete \
    --stack-name "$STACK_NAME" \
    --region "$AWS_REGION"
fi
echo "  ✓ CloudFormation stack deployed"

# --- Step 6: Create/Update M2 Application ------------------------------------
echo ""
echo "[6/6] Creating M2 Application..."

# Get M2 environment ID from CloudFormation output
M2_ENV_ID=$(aws cloudformation describe-stacks \
  --stack-name "$STACK_NAME" \
  --region "$AWS_REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='M2EnvironmentId'].OutputValue" \
  --output text)

echo "  M2 Environment ID: $M2_ENV_ID"

# Upload application definition
aws s3 cp config/m2-application-definition.yaml \
  "${S3_BASE}/m2-application-definition.yaml" \
  --region "$AWS_REGION"

# Create M2 Application
APP_DEF_S3="s3://${ARTIFACTS_BUCKET}/${APP_NAME}/${APP_VERSION}/m2-application-definition.yaml"

aws m2 create-application \
  --name "$APP_NAME" \
  --engine-type "microfocus" \
  --definition "s3Location={bucket=${ARTIFACTS_BUCKET},key=${APP_NAME}/${APP_VERSION}/m2-application-definition.yaml}" \
  --region "$AWS_REGION" \
  --tags "Environment=${ENV_NAME},Version=${APP_VERSION}" \
  2>/dev/null || echo "  Application may already exist - check AWS Console"

echo "  ✓ M2 Application registered"

echo ""
echo "============================================================"
echo "  ✅ Deployment Complete!"
echo ""
echo "  Next steps:"
echo "  1. Open AWS Console → Mainframe Modernization"
echo "  2. Find application: ${APP_NAME}"
echo "  3. Click 'Deploy to environment': ${ENV_NAME}"
echo "  4. Run batch job: CUSTJOB"
echo "============================================================"
